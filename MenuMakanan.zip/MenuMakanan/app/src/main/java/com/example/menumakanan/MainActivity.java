package com.example.menumakanan;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ArrayList<String> fotoMakanan = new ArrayList<>();
    private ArrayList<String> namaMakanan = new ArrayList<>();
    private ArrayList<String> infoMakanan = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        getDataFromInternet();
    }

    private void prosesRecyclerViewAdapter(){
        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        RecyclerViewAdapter adapter = new RecyclerViewAdapter(fotoMakanan, namaMakanan, infoMakanan, this);

        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));
    }

    private void getDataFromInternet(){
        namaMakanan.add("Nasi Gandul");
        fotoMakanan.add("https://img-global.cpcdn.com/recipes/fbd47fee71ea8e3e/680x482cq70/4-nasi-gandul-sego-gandul-khas-pati-resep-asli-foto-resep-utama.jpg");
        infoMakanan.add("Nasi gandul biasanya disantap saat sarapan. Terbuat dari nasi putih berkuah yang dipadukan potongan daging sapi. Disajikan di atas daun pisang yang membuat makanan ini terasa unik.");

        namaMakanan.add("Soto Kudus");
        fotoMakanan.add("https://assets.resepedia.id/assets/images/2020/09/1677908046143889-soto-kudus.jpg");
        infoMakanan.add("Soto kudus memiliki kuah yang lebih bening dibanding soto pada umumnya. Dilengkapi dengan ayam suwir, taoge, sohun, dan kol.");

        namaMakanan.add("Tahu Petis");
        fotoMakanan.add("https://nusadaily.com/wp-content/uploads/2020/02/tahu_petis.jpg");
        infoMakanan.add("Tahu petis terbuat dari tahu pong yang digoreng, lalu diberi isian bumbu petis hitam. Rasanya cenderung gurih dan pedas. Cocok jadi camilan saat santai.");

        namaMakanan.add("Lumpia Semarang");
        fotoMakanan.add("https://cdn-2.tstatic.net/tribunnews/foto/bank/images/lumpia-semarang-1.jpg");
        infoMakanan.add("Lumpia semarang berisi daging ayam atau udang, rebung, dan telur. Biasanya disajikan dengan saus kental manis yang terbuat dari campuran gula, bawang putih, dan tepung.");

        prosesRecyclerViewAdapter();
    }

}